rm -rf /data/adb/integrity_box
rm -rf /data/adb/tricky_store/keybox.xml
rm -rf /data/adb/tricky_store/target.txt
rm -rf /data/adb/modules/integrity_box
rm -rf /data/adb/modules/susfs4ksu/action.sh