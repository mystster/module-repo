# Changelog

- Migrated to **resetprop-rs** with a complete backend refactor and various internal improvements.

- Added **WebUI translation support**.
  - 🇨🇳 Chinese translation by **@LQ2002**
  - 🇮🇳 Hinglish translation by **Tehreem**

- Added ability to **hide kernel-related detections**.

- Synced with latest **PIF** source.

- Updated **system** and **vendor** security patch levels to **July 2026**.

- Improved **Keybox** script.

- Simplified and cleaned up scripts for better readability and maintenance.

- Changed Keybox backup source.

- Removed URL decoding.

- Removed force updater.

- Removed verification config updater.

- Cleaned up legacy code that is no longer used.

- Added a **Contributors** section to Support WebUI.

- Blacklisted selected browsers from accessing the Keybox, as they unnecessarily perform Play Integrity checks, which can ruin the Keybox.

- Updated Hashtag & URL in integrity downloader

- Updated HMA config