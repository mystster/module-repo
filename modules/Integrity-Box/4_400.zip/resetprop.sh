#!/system/bin/sh
MEOW() {
    am start -a android.intent.action.MAIN -e mona "$@" -n meow.helper/.MainActivity &>/dev/null
    sleep 0.5
}

BACKUP_DIR="/data/adb/Integrity-Box/pihooks_backup"
mkdir -p "$BACKUP_DIR"

PROPS="
persist.sys.pihooks_TAGS
persist.sys.pihooks_TYPE
persist.sys.pihooks_BRAND
persist.sys.pihooks_MODEL
persist.sys.pihooks_DEVICE
persist.sys.pihooks_PRODUCT
persist.sys.pihooks_RELEASE
persist.sys.pihooks_FINGERPRINT
persist.sys.pihooks_MANUFACTURE
persist.sys.pihooks_SECURITY_PA
persist.sys.pihooks_ID
persist.sys.pihooks_DEVICE_INIT
"

DISABLE_FLAGS="
persist.sys.pihooks.disable.gms
persist.sys.pihooks.disable.gms_props
persist.sys.pihooks.disable.gms_key_attestation_block
persist.sys.pixelprops.pi
persist.sys.pixelprops.all
persist.sys.pixelprops.gms
"

# Backup spoof props if they exist
for PROP in $PROPS; do
    if resetprop | grep -q "$PROP"; then
        resetprop "$PROP" > "$BACKUP_DIR/$(basename "$PROP")"
        resetprop -n -p "$PROP" ""
    fi
done

# Set all spoof flags to true (disable spoofing)
for PROP in $DISABLE_FLAGS; do
    resetprop -n -p "$PROP" true
done

MEOW "ROM SPOOFING DISABLED ✅"