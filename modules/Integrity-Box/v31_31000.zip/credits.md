## Credits
- @ez-me for https://github.com/ez-me/ezme-nodebug

- @osm0sis for https://github.com/osm0sis/PlayIntegrityFork

- @LSPosed team for Shamiko's late start service script https://github.com/LSPosed/LSPosed.github.io/releases

- Everyone who supported me

- You, for using this module 

- ☝️GOD, for everything🙌