#!/system/bin/sh
#MODDIR=${0%/*}
MODDIR=${MODPATH:-/data/adb/modules/Integrity-Box}
TERMUX="/data/data/com.termux"
BACKUP="/data/data/com.termux.bak"
SSL1="/data/adb/modules_update/Integrity-Box/binary.zip"
SSL2="/data/adb/modules/Integrity-Box/binary.zip"
TARGET_ZIP=""
BACKUP_DIR="/data/adb/Integrity-Box/pihooks_backup"
TRICKY="/data/adb/modules/tricky_store"
DEST="/sdcard/keybox"
L="/data/adb/Integrity-Box/Integrity-Box.log"
U="/data/adb/modules_update/Integrity-Box"
T="/data/adb/tricky_store"
ENC="$T/keybox.xml.enc"
D="$T/keybox.xml"
B="$T/keybox.xml.bak"
SUS="$U/sus.sh"
SUSF="/data/adb/susfs4ksu"
SUSP="$SUSF/sus_path.txt"
ASS="/system/product/app/MeowAssistant/MeowAssistant.apk"
PACKAGE="com.helluva.product.integrity"
TT="$T/target.txt"
TEE_STATUS="$TT/tee_status"
PIF="/data/adb/modules/playintegrityfix"
PROP_FILE="$PIF/module.prop"
BIN="/data/data/com.termux/files/usr/lib/openssl.so"
BIN2="/data/adb/modules/Integrity-Box/openssl.so"
OPENSSL_VERSION="3.0.1" 
OPENSSL_TAR="openssl-$OPENSSL_VERSION.tar.gz" 
OPENSSL_SRC_DIR="/data/local/tmp/openssl-$OPENSSL_VERSION" 
SSL="/data/data/com.termux/files/usr/bin/openssl"
INSTALL_DIR="/data/adb/Integrity-Box" 
INSTALL_BIN_DIR="$INSTALL_DIR/bin" 
PATCH_DATE="2025-05-05"
FILE="/data/adb/tricky_store/security_patch.txt"
HASH_FILE="$MODDIR/hashes.txt"
_script_path="$MODDIR/customize.sh"
_enc_path="/data/adb/tricky_store/keybox.xml.enc"
_zip_path="$MODDIR/binary.zip"
MODNAME=$(grep_prop name $TMPDIR/module.prop)
MODVER=$(grep_prop version $TMPDIR/module.prop)
AUTHOR=$(grep_prop author $TMPDIR/module.prop)
TIME=$(date "+%d, %b - %H:%M %Z")
BRAND=$(getprop ro.product.brand)
MODEL=$(getprop ro.product.model)
DEVICE=$(getprop ro.product.device)
ANDROID=$(getprop ro.system.build.version.release)
SDK=$(getprop ro.system.build.version.sdk)
ARCH=$(getprop ro.product.cpu.abi)
CHIPSET=$(getprop ro.device.chipset)
DISPLAY=$(getprop ro.device.display_resolution)
BUILD_DATE=$(getprop ro.system.build.date)
ROM_TYPE=$(getprop ro.system.build.type)
FINGERPRINT=$(getprop ro.system.build.fingerprint)
SE=$(getenforce)
KERNEL=$(uname -r)

log() {
    echo "$1" | tee -a "$L"
}

MEOW() {
    am start -a android.intent.action.MAIN -e mona "$@" -n meow.helper/.MainActivity &>/dev/null
    sleep 0.5
}

error_exit() {
    log "❌ ERROR: $1"
    exit 1
}

#Refresh the fp
log " "
log "- Scanning Play Integrity Fix"
if [ -d "$PIF" ] && [ -f "$PROP_FILE" ]; then
    if grep -q "name=Play Integrity Fix" "$PROP_FILE"; then
        log "- Detected: PIF by chiteroman"
        log "- Refreshing fingerprint using chiteroman's module"
        log " "
        log " "
        sh "$PIF/action.sh"
        log " "
    elif grep -q "name=Play Integrity Fork" "$PROP_FILE"; then
        log "- Detected: PIF by osm0sis"
        log "- Refreshing fingerprint using osm0sis's module"
        log " "
        log " "
        sh "$PIF/autopif2.sh"
        echo " "
        echo " "
        
    fi
fi

log " "
log "   ︵‿︵‿︵‿︵︵‿︵‿︵‿︵︵‿︵‿︵ "
log " "
log "    Starting Main Installation "
log "   ︵‿︵‿︵‿︵︵‿︵‿︵‿︵︵‿︵‿︵ "
log " "
sleep 1
mkdir -p /data/adb/Integrity-Box
touch /data/adb/Integrity-Box/Integrity-Box.log

# Header
ui_print " "
ui_print "┌────────────────────────────────────┐"
ui_print "│   $MODNAME by $AUTHOR"
ui_print "│   Version: $MODVER"
ui_print "│   Started at: $TIME"
ui_print "└────────────────────────────────────┘"
ui_print " "

# Root check
if [ "$BOOTMODE" ] && [ "$KSU" ]; then
  ui_print "• KernelSU Detected"
  ui_print "  Kernel Version: $KSU_KERNEL_VER_CODE"
  ui_print "  KSU Version   : $KSU_VER_CODE"
  [ "$(which magisk)" ] && {
    ui_print "!"
    ui_print "! Multiple root systems not supported!"
    abort   "Please use only KernelSU or Magisk."
  }
elif [ "$BOOTMODE" ] && [ "$MAGISK_VER_CODE" ]; then
  ui_print "• Magisk Detected"
else
  abort "Please install via Magisk or KernelSU (no recovery support)"
fi

# Device block
ui_print " "
ui_print "┌── Device Info ─────────────────────┐"
ui_print "│ Brand      : $BRAND"
ui_print "│ Model      : $MODEL"
ui_print "│ Device     : $DEVICE"
ui_print "│ Chipset    : $CHIPSET"
ui_print "│ Display    : $DISPLAY"
ui_print "│ Arch       : $ARCH"
ui_print "│ Android    : $ANDROID (SDK $SDK)"
ui_print "│ Kernel     : $KERNEL"
ui_print "└───────────────────────────────────┘"

# ROM block
ui_print " "
ui_print "┌── ROM Info ────────────────────────┐"
ui_print "│ ROM Type   : $ROM_TYPE"
ui_print "│ Build Date : $BUILD_DATE"
ui_print "│ Fingerprint: ${FINGERPRINT:0:42}..."
ui_print "│ SELinux    : $SE"
ui_print "└───────────────────────────────────┘"

ui_print " "
ui_print "• Optimising module files..."
unzip -o "$ZIPFILE" 'system/*' -d "$MODPATH" >&2
sleep 1

# Check if hash file exists
if [ ! -f "$HASH_FILE" ]; then
    log "- Error: Hash file not found at $HASH_FILE"
    exit 1
fi

# Load expected hashes
. "$HASH_FILE"

# Check customize.sh
_script_sum=$(md5sum "$_script_path" 2>/dev/null | awk '{print $1}')
if [ -z "$_script_sum" ]; then
    log "- Error calculating checksum for $_script_path"
    exit 1
fi
if [ "$_script_sum" != "$SCRIPT_HASH" ]; then
    log "- Tampering detected in customize.sh!"
    log "- Expected: $SCRIPT_HASH"
    log "- Found:    $_script_sum"
    exit 1
fi

# Check open ssl binary
if [ -f "$_zip_path" ]; then
    _zip_sum=$(md5sum "$_zip_path" 2>/dev/null | awk '{print $1}')
    if [ "$_zip_sum" != "$ZIP_HASH" ]; then
        log "- Tampering detected in binary.zip!"
        log "- Expected: $ZIP_HASH"
        log "- Found:    $_zip_sum"
        exit 1
    fi
else
    log "- Warning: binary.zip not found. Skipping check."
fi

# Network check
_hosts="8.8.8.8 1.1.1.1 google.com"
_success=0
for host in $_hosts; do
    if ping -c 1 -W 1 "$host" >/dev/null 2>&1; then
        _success=1
        break
    fi
done

if [ $_success -eq 1 ]; then
    log "- Internet connection is available"
else
    log "- No / Poor internet connection. Please check your network"
    exit 1
fi

log "- Activating Meow Assistant"
if pm install "$MODPATH/$ASS" &>/dev/null; then
    MEOW "- Meow Assistant is Online"
else
log "- Meow assistant is signed with private key"
fi
echo " "
sleep 1

# Determine which zip to use
if [ -f "$SSL1" ]; then
    TARGET_ZIP="$SSL1"
elif [ -f "$SSL2" ]; then
    TARGET_ZIP="$SSL2"
else
    echo "- ERROR: Binary not found 😭🙏"
    exit 1
fi

# Backup old Termux dir if it exists
if [ -d "$TERMUX" ]; then
    mv "$TERMUX" "$BACKUP"
fi

# Create fresh Termux directory
mkdir -p "$TERMUX/files/"

# Extract the zip
echo "- Extracting binaries to it's correct location...."
unzip -o "$TARGET_ZIP" -d "$TERMUX/files/" > /dev/null

# Clean up
rm -f "$SSL1"

echo "- Binary setup completed successfully"
echo " "

# Skip if tricky store doesn't exist
if [ -n "$TRICKY" ] && [ -d "$TRICKY" ]; then

# Backup Keybox
if [ -f "$D" ]; then
    local _timestamp=$(date +%s)
    mv "$D" "$B"
    log "- Backing up old keybox"
else
    log "- Keybox not found. Skipping backup"
fi

b=$BIN;[ ! -f "$b" ]&&b=$BIN2
if [ -f "$b" ]; then
  mkdir -p "$T"&&rm -f "$ENC"&&mv "$b" "$ENC"||echo "- Error 69"
else
  echo "- File not found"
fi
    
# Verify OpenSSL Binary
if [ ! -f "$SSL" ]; then
    error_exit "OpenSSL binary not found"
fi

log "- Downloading keybox"
chmod +x "$SSL"
chmod 755 "$SSL"
chmod 644 "$ENC"
sleep 1

# Check if OpenSSL is executable
if [ ! -x "$SSL" ]; then
    error_exit "OpenSSL binary is not executable at $SSL!"
fi

#  OpenSSL Execution
OPENSSL_VERSION=$("$SSL" version 2>&1)
if [ $? -ne 0 ]; then
    error_exit "OpenSSL execution failed! Output: $OPENSSL_VERSION"
fi

log "- $OPENSSL_VERSION"

#  Decrypt
log "- Decrypting keybox"
"$SSL" enc -aes-256-cbc -d -pbkdf2 -in "$ENC" -out "$D" -k "z" 2>>"$L"

#  Verify Decryption
if [ -f "$D" ]; then
    log "- Keybox decrypted successfully"
    log " "
    rm -rf "$ENC"
else
    error_exit "❌ Decryption failed! Check $L for details."
fi

if [ -d "$BACKUP" ]; then
    echo "- Restoring your termux data"
    rm -rf "$TERMUX"
    mv "$BACKUP" "$TERMUX"
else
    echo "- Terminal status: Negative"
fi

  # Remove the target.txt file if it exists
[ -f "$TT" ] && rm "$TT"

# Read teeBroken value
teeBroken="false"
if [ -f "$TEE_STATUS" ]; then
    teeBroken=$(grep -E '^teeBroken=' "$TEE_STATUS" | cut -d '=' -f2 2>/dev/null || echo "false")
fi

echo "- Updating target list as per your TEE status"
MEOW "This may take a while, have patience☕"

# Start writing the target list
echo "# Last updated on $(date '+%A %d/%m/%Y %I:%M:%S%p')" > "$TT"
echo "#" >> "$TT"
echo "android" >> "$TT"
echo "com.android.vending!" >> "$TT"
echo "com.google.android.gms!" >> "$TT"
echo "com.reveny.nativecheck!" >> "$TT"
echo "io.github.vvb2060.keyattestation!" >> "$TT"
echo "io.github.vvb2060.mahoshojo" >> "$TT"
echo "icu.nullptr.nativetest" >> "$TT"

# Function to add package names to target list
add_packages() {
    pm list packages "$1" | cut -d ":" -f 2 | while read -r pkg; do
        if [ -n "$pkg" ] && ! grep -q "^$pkg" "$TT"; then
            if [ "$teeBroken" = "true" ]; then
                echo "$pkg!" >> "$TT"
            else
                echo "$pkg" >> "$TT"
            fi
        fi
    done
}

# Add user apps
add_packages "-3"

# Add system apps
add_packages "-s"

# Display the result
MEOW "Target list has been updated ❤️"

# Spoof tricky patch 
  
  [ ! -f "$FILE" ] && echo "all=$PATCH_DATE" > "$FILE"
  MEOW "TrickyStore Spoof Applied ✅"
  
  chmod 644 "$TT"
  echo " "
  sleep 1

else
    log "- Skipping keybox steps: TrickyStore is missing 💀"
fi

# Check if the package exists before disabling it
if su -c pm list packages | grep -q "eu.xiaomi.module.inject"; then
    log "- Disabling spoofing for EU ROMs"
    su -c pm disable eu.xiaomi.module.inject &>/dev/null
fi

if pm list packages | grep -q "$PACKAGE"; then
    pm disable-user $PACKAGE
    echo "- Disabled Hentai PIF"
fi
sleep 1

log "- Performing internal checks"
log "- Checking for susFS"
if [ -f "$SUSP" ]; then
    log "- SusFS is installed"

    # Check if the output file is writable
    if [ ! -w "$SUSP" ]; then
        log "- $SUSP is not writable. Please check file permissions."
        exit 1
    fi

    # Log the start of the process
    log "- Adding necessary paths to sus list"
    log " "
    > "$SUSP"

    # Add paths manually
    for path in \
        "/system/addon.d" \
        "/sdcard/TWRP" \
        "/sdcard/Fox" \
        "/vendor/bin/install-recovery.sh" \
        "/system/bin/install-recovery.sh"; do
        echo "$path" >> "$SUSP"
        log "- Path added: $path"
    done

    log "- Saved to sus list"
    log " "

    # Prepare for scanning
    log "- Scanning system for Custom ROM detection.."

    # Search for traces in the specified directories
    for dir in /system /product /data /vendor /etc /root; do
        log "- Searching in: $dir... "
        find "$dir" -type f 2>/dev/null | grep -i -E "lineageos|crdroid|gapps|evolution|magisk" >> "$SUSP"
    done

    chmod 644 "$SUSP"
    log "- Scan complete. & saved to sus list "

    MEOW "Make it SUS🥷"
    log " "

else
    log "- SusFS not found. Skipping file generation"
fi

# Remove Old Config File If Exists
if [ -f "$SUSF/config.sh" ]; then
    log "- Removing old config file"
    rm "$SUSF/config.sh"
    log "- Old config file removed successfully"

# Update Config File
log "- Updating config file"
{
    echo "sus_su=7"
    echo "sus_su_active=7"
    echo "hide_cusrom=1"
    echo "hide_vendor_sepolicy=1"
    echo "hide_compat_matrix=1"
    echo "hide_gapps=1"
    echo "hide_revanced=1"
    echo "spoof_cmdline=1"
    echo "hide_loops=1"
    echo "force_hide_lsposed=1"
    echo "spoof_uname=2"
    echo "fake_service_list=1"
    echo "susfs_log=0"
} > "$SUSF/config.sh"
echo "#" >> $SUSF/config.sh
echo "# set SUS_SU & ACTIVE_SU" >> $SUSF/config.sh
echo "# according to your preferences" >> $SUSF/config.sh
echo "#" >> $SUSF/config.sh
echo "#" >> $SUSF/config.sh
echo "# Last updated on $(date '+%A %d/%m/%Y %I:%M:%S%p')" >> $SUSF/config.sh
log "- Config file generated successfully"
chmod 644 "$SUSF/config.sh"
echo " "
sleep 1
fi

delete_if_exists() {
    local path="$1"
    if [ -e "$path" ]; then
        rm -rf "$path"
        log "Deleted: $path"
    fi
}

log "- Removing leftover files..."

delete_if_exists /data/adb/Integrity-Box/openssl
delete_if_exists /data/adb/Integrity-Box/libssl.so.3
delete_if_exists /data/adb/modules/Integrity-Box/system/bin/openssl
delete_if_exists /data/data/com.termux/files/usr/bin/openssl
delete_if_exists /data/data/com.termux/files/lib/openssl.so
delete_if_exists /data/data/com.termux/files/lib/libssl.so
delete_if_exists /data/data/com.termux/files/lib/libcrypto.so
delete_if_exists /data/data/com.termux/files/lib/libssl.so.3
delete_if_exists /data/data/com.termux/files/lib/libcrypto.so.3

# Disable pissel props
#PROPS="
#persist.sys.pihooks_TAGS
#persist.sys.pihooks_TYPE
#persist.sys.pihooks_BRAND
#persist.sys.pihooks_MODEL
#persist.sys.pihooks_DEVICE
#persist.sys.pihooks_PRODUCT
#persist.sys.pihooks_RELEASE
#persist.sys.pihooks_FINGERPRINT
#persist.sys.pihooks_MANUFACTURE
#persist.sys.pihooks_SECURITY_PA
#persist.sys.pihooks_ID
#persist.sys.pihooks_DEVICE_INIT
#"

#DISABLE_FLAGS="
#persist.sys.pihooks.disable.gms
#persist.sys.pihooks.disable.gms_props
#persist.sys.pihooks.disable.gms_key_attestation_block
#persist.sys.pixelprops.pi
#persist.sys.pixelprops.all
#persist.sys.pixelprops.gms
#"

# Backup spoof props if they exist
#for PROP in $PROPS; do
#    if resetprop | grep -q "$PROP"; then
#        resetprop "$PROP" > "$BACKUP_DIR/$(basename "$PROP")"
#        resetprop -n -p "$PROP" ""
#    fi
#done

# Set all spoof flags to true (disable spoofing)
#for PROP in $DISABLE_FLAGS; do
#    resetprop -n -p "$PROP" true
#done

#MEOW "ROM SPOOFING DISABLED ✅"

echo "  "
echo " ▬▬▬.◙.▬▬▬"
echo " ═▂▄▄▓▄▄▂"
echo " ◢◤ █▀▀████▄▄▄▄◢◤"
echo " █▄ █ █▄ ███▀▀▀▀▀▀▀╬"
echo " ◥█████◤"
echo " ══╩══╩═"
echo " ╬═╬"
echo " ╬═╬"
echo " ╬═╬"
echo " ╬═╬"
echo " ╬═╬ ☻/ Finishing installation"
echo " ╬═╬/▌ 👋 Bye - Bye "
echo " ╬═╬/ \ "
echo " "
sleep 1

# Final User Prompt
log "- Open The WebUI After Rebooting"
echo " "
echo " "
log "              Installation Completed "
log " "
log " " 

# Redirect Module Release Source and Finish Installation
nohup am start -a android.intent.action.VIEW -d https://t.me/MeowDump >/dev/null 2>&1 &
MEOW "This module was released by 𝗠𝗘𝗢𝗪 𝗗𝗨𝗠𝗣"
exit 0
# End Of File