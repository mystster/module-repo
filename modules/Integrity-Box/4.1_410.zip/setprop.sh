#!/system/bin/sh
MEOW() {
    am start -a android.intent.action.MAIN -e mona "$@" -n meow.helper/.MainActivity &>/dev/null
    sleep 0.5
}

BACKUP_DIR="/data/adb/Integrity-Box/pihooks_backup"

DISABLE_FLAGS="
persist.sys.pihooks.disable.gms
persist.sys.pihooks.disable.gms_props
persist.sys.pihooks.disable.gms_key_attestation_block
persist.sys.pixelprops.pi
persist.sys.pixelprops.all
persist.sys.pixelprops.gms
"

# Re-enable spoofing by resetting spoof-disable flags
for PROP in $DISABLE_FLAGS; do
    resetprop -n -p "$PROP" false
done

# Restore backed up spoof props
for FILE in "$BACKUP_DIR"/*; do
    PROP="persist.sys.pihooks_$(basename "$FILE")"
    VALUE="$(cat "$FILE")"
    resetprop -n -p "$PROP" "$VALUE"
done

MEOW "ROM SPOOFING ENABLED✅"