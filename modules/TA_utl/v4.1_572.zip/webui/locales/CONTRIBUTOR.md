# Translation Contributor List

## Arabic

- [ZG089](https://github.com/ZG089)

---

## Azerbaijani

- [mnasibzade](https://github.com/mnasibzade)

---

## Chinese (Simplified)

- [xiaokuqwq](https://github.com/xiaokuqwq)

---

## French

- [anaelle-dev](https://github.com/anaelle-dev)
- [GhostFRR](https://github.com/GhostFRR)

---

## German

- [xxOrdulu52xx](https://github.com/xxOrdulu52xx)

---

## Greek

- [Goku818](https://github.com/Goku818)

---

## Indonesian

- [chisewaguri](https://github.com/chisewaguri)
- [Rem01Gaming](https://github.com/Rem01Gaming)

---

## Italian

- [luigimak](https://github.com/luigimak)
- [GRgabrix](https://github.com/GRgabrix)

---

## Japanese

- [reindex-ot](https://github.com/reindex-ot)

---

### Polish

- [Bladius2024](https://github.com/Bladius2024)

---

## Portuguese (Brazilian)

- [JeanxPereira](https://github.com/JeanxPereira)
- [SecretGogeta](https://github.com/SecretGogeta)

---

## Spanish

- [Keinta15](https://github.com/Keinta15)

---

## Turkish

- [berkmirsatk](https://github.com/berkmirsatk)
- [cvnertnc](https://github.com/cvnertnc)

---

## Ukrainian

- [StepanSad](https://github.com/StepanSad)
- [IlliaS](https://github.com/IlliaS)
