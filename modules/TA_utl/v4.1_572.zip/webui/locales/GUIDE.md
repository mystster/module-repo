# Translation Guide

## Update Existing Language

- Update translation in [Crowdin](https://crowdin.com/project/TA_utl).
- Add your name to [translation contibutor list](https://github.com/KOWX712/Tricky-Addon-Update-Target-List/blob/main/module/webui/locales/CONTRIBUTOR.md) (Issue/Pull Request).

---

## Add a New Language

- Create you translation based on [template](https://github.com/KOWX712/Tricky-Addon-Update-Target-List/blob/main/module/webui/locales/template.xml).
- Create an [issues](https://github.com/KOWX712/Tricky-Addon-Update-Target-List/issues/new/choose) for language request and upload translated file in zip format (compressed).
