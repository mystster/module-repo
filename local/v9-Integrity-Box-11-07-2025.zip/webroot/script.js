const MODDIR = "/data/adb/modules/integrity_box/webroot/common_scripts";
const PROP = `/data/adb/modules/integrity_box/module.prop`;

const modalBackdrop = document.getElementById("modal-backdrop");
const modalTitle = document.getElementById("modal-title");
const modalOutput = document.getElementById("modal-output");
const modalClose = document.getElementById("modal-close");
const modalContent = document.getElementById("modal-content");

function runShell(command) {
  if (typeof ksu !== "object" || typeof ksu.exec !== "function") {
    return Promise.reject("KernelSU JavaScript API not available.");
  }
  const cb = `cb_${Date.now()}`;
  return new Promise((resolve, reject) => {
    window[cb] = (code, stdout, stderr) => {
      delete window[cb];
      code === 0 ? resolve(stdout) : reject(new Error(stderr || "Shell command failed"));
    };
    ksu.exec(command, "{}", cb);
  });
}

function popup(msg) {
  return runShell(`am start -a android.intent.action.MAIN -e mona "${msg}" -n popup.toast/.MainActivity`);
}

function openModal(title, content, fullscreen = false) {
  modalTitle.textContent = title;
  modalOutput.innerHTML = content || "Loading...";
  modalBackdrop.classList.remove("hidden");

  if (fullscreen) {
    modalBackdrop.classList.add("fullscreen");
    modalContent.classList.add("fullscreen");
    modalOutput.classList.add("fullscreen");
  } else {
    modalBackdrop.classList.remove("fullscreen");
    modalContent.classList.remove("fullscreen");
    modalOutput.classList.remove("fullscreen");
  }
}

function closeModal() {
  modalBackdrop.classList.add("hidden");
}

async function getModuleName() {
  try {
    const name = await runShell(`grep '^name=' ${PROP} | cut -d= -f2`);
    document.getElementById("module-name").textContent = name.trim();
    document.title = name.trim();
  } catch {
    document.getElementById("module-name").textContent = "integrity_box";
  }
}

async function updateDashboard() {
  const statusWhitelist = document.getElementById("status-whitelist");
  const statusGms = document.getElementById("status-gms");
  const statusSusfs = document.getElementById("status-susfs");

  try {
    await runShell("[ -f /data/adb/nohello/whitelist ] || [ -f /data/adb/shamiko/whitelist ]");
    statusWhitelist.textContent = "Enabled";
    statusWhitelist.className = "status-indicator enabled";
  } catch {
    statusWhitelist.textContent = "Disabled";
    statusWhitelist.className = "status-indicator disabled";
  }

  try {
    const gmsProp = await runShell("getprop persist.sys.pihooks.disable.gms_props");
    statusGms.textContent = gmsProp.trim() === "true" ? "Disabled" : "Enabled";
    statusGms.className = gmsProp.trim() === "true" ? "status-indicator enabled" : "status-indicator disabled";
  } catch {
    statusGms.textContent = "Unknown";
    statusGms.className = "status-indicator";
  }

  try {
    await runShell("[ -d /data/adb/modules/susfs4ksu ]");
    statusSusfs.textContent = "Detected";
    statusSusfs.className = "status-indicator enabled";
  } catch {
    statusSusfs.textContent = "Not Found";
    statusSusfs.className = "status-indicator disabled";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  getModuleName();
  updateDashboard();

  const sparkleContainer = document.querySelector('.sparkle-container');
  if (sparkleContainer) {
    for (let i = 0; i < 40; i++) {
      const sparkle = document.createElement('div');
      sparkle.classList.add('sparkle');
      sparkle.style.top = `${Math.random() * 100}%`;
      sparkle.style.left = `${Math.random() * 100}%`;
      sparkle.style.animationDelay = `${Math.random() * 3}s`;
      sparkleContainer.appendChild(sparkle);
    }
  }

  const introSubtext = document.getElementById("intro-subtext");
  if (introSubtext) {
    const quotes = [
      "Indeed, With Hardship Comes Ease",
      "Work Hard Dream Big",
      "Push Yourself Because No One Else Will",
      "Stay Focused Never Give Up",
      "Believe In Yourself",
      "Success Starts With Effort",
      "Discipline Is Greater Than Motivation",
      "Dream It Wish It Do It",
      "Your Mind Is Your Power",
      "Small Steps Every Day",
      "Hustle In Silence Let Success Speak",
      "Touch Some Grass",
      "There's No Tomorrow",
      "Fear None But One☝️",
      "The World Is A Prison For The Believer",
      "Whoever Remains Silent Is Saved",
      "Die Before You Die",
      "Detach From What Dims Your Heart",
      "Every Soul Shall Taste Death"
    ];

    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    const words = randomQuote.split(" ");

    introSubtext.innerHTML = "";
    words.forEach((word, index) => {
      const span = document.createElement("span");
      span.textContent = word;
      span.style.opacity = 0;
      span.style.display = "block";
      span.style.fontWeight = "bold";
      span.style.fontSize = "5.2rem";
      span.style.textAlign = "center";
      span.style.transition = "opacity 0.3s ease-in-out";
      span.style.animation = `fadeInWord 0.4s ease forwards ${index * 0.5}s`;
      introSubtext.appendChild(span);
    });
  }

  setTimeout(() => {
    const overlay = document.getElementById("intro-overlay");
    if (overlay) overlay.remove();
  }, 6000);

  document.querySelectorAll(".btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const script = btn.dataset.script;
      const type = btn.dataset.type;
      const command = `sh ${MODDIR}/${script}`;
      btn.classList.add("loading");

      try {
        if (type === "scanner") {
          openModal(btn.innerText.trim(), "Running scan...", true);
          const output = await runShell(command);
          modalOutput.innerHTML = (output || "Script executed with no output.").replace(/\n/g, "<br>");
        } else if (type === "hash") {
          const output = await runShell(`sh ${MODDIR}/boot_hash.sh get`);
          const lines = output.trim().split(/\r?\n/);
          const saved = lines[1]?.trim() || "";
          const content = `
            <div style="display:flex;flex-direction:column;gap:1rem">
              <label>Enter Verified Boot Hash:</label>
              <input id="new-hash" type="text" value="${saved}" placeholder="abcdef1234..." style="width:100%;padding:0.5rem;font-size:0.9rem;border-radius:8px;border:1px solid var(--border-color);background:var(--panel-bg);color:var(--fg);" />
              <div style="display:flex;gap:1rem;flex-wrap:wrap;">
                <button class="btn" id="apply-hash"><span class="icon material-symbols-outlined">done</span>Apply</button>
                <button class="btn" id="reset-hash"><span class="icon material-symbols-outlined">restart_alt</span>Reset</button>
              </div>
            </div>
          `;
          openModal("Set Verified Boot Hash", content, true);
          setTimeout(() => {
            document.getElementById("apply-hash")?.addEventListener("click", async () => {
              const hash = document.getElementById("new-hash").value.trim();
              const cmd = hash ? `sh ${MODDIR}/boot_hash.sh set ${hash}` : `sh ${MODDIR}/boot_hash.sh clear`;
              try {
                await runShell(cmd);
                popup("Boot hash applied ✅");
              } catch {
                popup("Failed to apply hash ❌");
              } finally {
                await runShell(`sh ${MODDIR}/resethash.sh clear`);
                closeModal();
              }
            });

            document.getElementById("reset-hash")?.addEventListener("click", async () => {
              modalOutput.innerHTML = "Resetting...";
              try {
                await runShell(`sh ${MODDIR}/boot_hash.sh clear`);
                popup("Boot hash reset ✅");
              } catch {
                popup("Failed to reset ❌");
              } finally {
                closeModal();
              }
            });
          }, 100);
        } else if (type === "game") {
          const gameFrame = document.createElement("iframe");
          gameFrame.src = "./game/index.html";
          gameFrame.style.border = "none";
          gameFrame.style.width = "100%";
          gameFrame.style.height = "100%";
          gameFrame.style.flex = "1";
          gameFrame.style.borderRadius = "0";

          openModal("", "", true);
          modalOutput.innerHTML = "";
          modalOutput.appendChild(gameFrame);
          return;
        } else if (script === "support") {
          // keep your donate modal as-is
        } else {
          await runShell(command);
        }
      } catch (error) {
        if (type === "scanner") {
          modalOutput.textContent = `Error executing script:\n\n${error.message}`;
        } else {
          popup(`Error: ${error.message}`);
        }
      } finally {
        btn.classList.remove("loading");
        setTimeout(updateDashboard, 1000);
      }
    });
  });

  modalClose.addEventListener("click", closeModal);
  modalBackdrop.addEventListener("click", (e) => {
    if (e.target === modalBackdrop) closeModal();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !modalBackdrop.classList.contains("hidden")) {
      closeModal();
    }
  });

  const langDropdown = document.getElementById("lang-dropdown");
  langDropdown.addEventListener("change", async () => {
    const lang = langDropdown.value;
    document.documentElement.setAttribute("dir", lang === "ar" || lang === "ur" ? "rtl" : "ltr");

    try {
      const module = await import(`./lang/${lang}.js`);
      const { translations, buttonGroups, buttonOrder } = module;

      document.querySelectorAll(".group-title").forEach(title => {
        const originalKey = title.dataset.key || title.textContent;
        if (!title.dataset.key) title.dataset.key = originalKey;
        if (buttonGroups[originalKey] && buttonGroups[originalKey][lang]) {
          title.textContent = buttonGroups[originalKey][lang];
        }
      });

      const labels = translations[lang] || translations["en"];
      buttonOrder.forEach((scriptName, index) => {
        const btn = document.querySelector(`.btn[data-script='${scriptName}']`);
        if (btn) {
          const icon = btn.querySelector('.icon');
          const spinner = btn.querySelector('.spinner');
          const label = labels[index] || btn.textContent.trim();
          btn.innerHTML = '';
          if (icon) btn.appendChild(icon);
          btn.appendChild(document.createTextNode(label));
          if (spinner) btn.appendChild(spinner);
        }
      });
    } catch (e) {
      console.error("Failed to load language file", e);
    }
  });

  langDropdown.dispatchEvent(new Event("change"));

  const toggle = document.getElementById("theme-toggle");
  function applyTheme(theme) {
    if (theme === "light") {
      document.documentElement.classList.remove("dark");
      document.documentElement.classList.add("light");
      toggle.checked = false;
    } else {
      document.documentElement.classList.remove("light");
      document.documentElement.classList.add("dark");
      toggle.checked = true;
    }
  }

  const introText = document.querySelector('.intro-text');
  if (introText && document.documentElement.classList.contains('light')) {
    introText.style.color = '#ec407a';
    introText.style.borderRight = '2px solid #ec407a';
  }

  const savedTheme = localStorage.getItem("theme") || "dark";
  applyTheme(savedTheme);

  toggle.addEventListener("change", () => {
    const newTheme = toggle.checked ? "dark" : "light";
    localStorage.setItem("theme", newTheme);
    applyTheme(newTheme);
  });
});