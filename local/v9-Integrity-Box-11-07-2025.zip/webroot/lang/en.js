export const translations = {
  "en": [
    "Disable Auto-Whitelist Mode",
    "Enable Auto-Whitelist Mode",
    "Add All Apps in Target List",
    "Add Only User Apps in Target List",
    "Switch to Default Keybox",
    "Switch to AOSP Keybox",
    "Set Custom PIF prop/json",
    "Kill GMS Process",
    "Spoof PIF Injection values",
    "Spoof Tricky Store Patch",
    "Update SusFS Configuration",
    "Get Banned Keybox List",
    "Hide GMS Prop Detections",
    "Enable Inbuilt GMS Spoofing",
    "FIX Device not Certified",
    "Abnormal Detection",
    "Flagged Apps",
    "Props Detection",
    "Report a Problem/Bug",
    "Join Help Group",
    "Join Update Channel",
    "Support the Developer",
//    "Source Code"
  ]
};

export const buttonGroups = {
  "System & Toggles": { "en": "System & Toggles" },
  "Spoofing & Patching": { "en": "Spoofing & Patching" },
  "Diagnostics": { "en": "Diagnostics" },
  "Community & Info": { "en": "Community & Info" }
};

export const buttonOrder = [
  "stop.sh", "start.sh", "systemuser.sh", "user.sh",
  "keybox.sh", "aosp.sh", "pif.sh", "kill.sh",
  "spoof.sh", "patch.sh", "sus.sh", "banned.sh",
  "setprop.sh", "resetprop.sh", "vending.sh",
  "abnormal.sh", "app.sh", "prop.sh", "issue.sh",
  "meowverse.sh", "meowdump.sh", "support.sh", "info.sh"
];