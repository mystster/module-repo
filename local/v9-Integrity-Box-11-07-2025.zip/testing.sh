#!/system/bin/sh

PIF_PROP="/data/adb/modules/playintegrityfix/pif.prop"
BACKUP="/data/adb/modules/playintegrityfix/pif.prop.bak"
LOG_FILE="/data/adb/Integrity-Box-Logs/spoofing.log"

# Popup function
popup() {
    am start -a android.intent.action.MAIN -e mona "$@" -n popup.toast/meow.helper.MainActivity > /dev/null
    sleep 0.5
}

# Logger function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE"
}

# Backup original prop file
if [ -f "$PIF_PROP" ]; then
    cp -f "$PIF_PROP" "$BACKUP"
    log "📦 Backup created: $BACKUP"
else
    log "❌ $PIF_PROP not found!"
    popup "❌ pif.prop file not found!"
    exit 1
fi

# Function to toggle boolean props
toggle_bool() {
  local key="$1"
  local value
  value=$(grep -E "^$key=" "$PIF_PROP" | cut -d'=' -f2)

  if [ "$value" = "true" ]; then
    sed -i "s/^$key=true/$key=false/" "$PIF_PROP"
    log "$key → false"
  elif [ "$value" = "false" ]; then
    sed -i "s/^$key=false/$key=true/" "$PIF_PROP"
    log "$key → true"
  else
    log "$key not found or not boolean"
  fi
}

# Function to force set a key to false
force_false() {
  local key="$1"
  sed -i "s/^$key=.*/$key=false/" "$PIF_PROP"
  log "$key → forced to false"
}

# Header
log "──────── TOGGLE SPOOF FLAGS ────────"

# Toggle only these flags
for key in spoofBuild spoofProvider spoofSignature spoofProps; do
  toggle_bool "$key"
done

# Always force these to false
force_false DEBUG
force_false spoofVendingSdk

# Footer
log "✅ Toggling complete (with forced false values)"
popup "Spoofing flags updated!"